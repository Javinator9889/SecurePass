package javinator9889.securepass.errors.drive;

/**
 * Created by Javinator9889 on 06/04/2018.
 */
public class GoogleDriveNotAvailableException extends RuntimeException {
    /**
     * {@inheritDoc}
     */
    public GoogleDriveNotAvailableException(String message) {
        super(message);
    }
}
