CREATE TABLE IF NOT EXISTS SecurityCodes (
    idSecurityCodes INTEGER NOT NULL DEFAULT 0,
    accountName VARCHAR(45) NOT NULL,
    PRIMARY KEY (idSecurityCodes));