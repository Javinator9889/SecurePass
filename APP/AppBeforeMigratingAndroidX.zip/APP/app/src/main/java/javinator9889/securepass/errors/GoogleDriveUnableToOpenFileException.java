package javinator9889.securepass.errors;

/**
 * Created by Javinator9889 on 07/04/2018.
 */
public class GoogleDriveUnableToOpenFileException extends RuntimeException {
    public GoogleDriveUnableToOpenFileException(String message) {
        super(message);
    }
}
