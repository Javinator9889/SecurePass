package javinator9889.securepass.backup.drive;

/**
 * Created by Javinator9889 on 24/08/2018.
 */
public interface IDriveUploader {
//    void createFileInAppFolder();
    void uploadDatabase();
}
