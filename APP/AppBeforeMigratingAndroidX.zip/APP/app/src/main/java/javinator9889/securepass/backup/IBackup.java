package javinator9889.securepass.backup;

/**
 * Created by Javinator9889 on 20/09/2018.
 */
public interface IBackup {
    void doBackup();
    void restoreBackup();
}
