package javinator9889.securepass.util.values;

/**
 * Created by Javinator9889 on 18/05/2018.
 */
public enum DatabaseTables {
    CATEGORY, ENTRY, QR_CODE, SECURITY_CODE, FIELD, IMAGE, PASSWORD, LONG_TEXT, SMALL_TEXT,
    CONFIGURATION, PASS_CONFIG, SMALL_TEXT_CONFIG, LONG_TEXT_CONFIG, IMAGES_CONFIG
}
