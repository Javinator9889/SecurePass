package javinator9889.securepass.errors;

/**
 * Created by Javinator9889 on 07/04/2018.
 */
public class NoSHA2AlgorithmException extends Throwable {
    public NoSHA2AlgorithmException(String message) {
        super(message);
    }
}
