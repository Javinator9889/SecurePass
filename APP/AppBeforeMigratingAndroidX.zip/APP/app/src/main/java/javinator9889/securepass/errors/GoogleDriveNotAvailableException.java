package javinator9889.securepass.errors;

/**
 * Created by Javinator9889 on 06/04/2018.
 */
public class GoogleDriveNotAvailableException extends RuntimeException {
    public GoogleDriveNotAvailableException(String message) {
        super(message);
    }
}
